import { Component, OnInit, ElementRef, ViewChild, HostListener, NgZone } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  showSpinner: boolean;
  @ViewChild('rewards') public rewards:ElementRef;
  @ViewChild('aboutus') public aboutus:ElementRef;
  @ViewChild('myHeader') public myheader:ElementRef;
  @ViewChild('howtoplay') public howtoplay:ElementRef;

    public moveToStructure():void {
            this.rewards.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'end', inline: 'start' });
    }

    public moveToaboutus():void {
      this.aboutus.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'end', inline: 'start' });
}

public moveTohowtoplay():void {
  this.howtoplay.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'end', inline: 'start' });
}

  constructor(private router:Router,private ngZone: NgZone) {
    document.body.scrollTop = 0;
    document.body.scrollTo(0,0);
   // window.scroll(0,0);
    // window.scrollTo(0,window.screenTop);
    // window.scrollY;
    // window.screenTop;
    //this.topFunction();
   }

  private eventOptions: boolean|{capture?: boolean, passive?: boolean};

  topFunction() {
  //  this.myheader.nativeElement.scrollIntoView({ behavior: 'smooth', block: 'end', inline: 'start' });
  }

  ngOnInit() {
    this.showSpinner = true;
    window.scrollTo(0,window.screenTop);
    this.eventOptions = true;
  // this.ngZone.runOutsideAngular(() => {
  //     window.addEventListener('scroll', this.scroll, <any>this.eventOptions);
  // });
  }

  scroll = (): void => {
    if (true) {
       this.ngZone.run(() => {
        console.debug("Scroll Event");
        const mybutton = document.getElementById("myBtn");
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
          mybutton.style.display = "block";
        } else {
          mybutton.style.display = "none";
        }

        // const newLocal = "myHeader";
        // var header = document.getElementById(newLocal);
        // var sticky = header.offsetTop;
    
        // if (window.pageYOffset > sticky) {
        //   header.classList.remove("banner");
        //   header.classList.add("scrollbanner");
          
        // } else {
        //   header.classList.add("banner");
        //   header.classList.remove("scrollbanner");
        // }
       });
    }
};  

  onRewardsClick(){
   // this.router.navigateByUrl("/aboutus");
   this.moveToStructure();
  }

  onHowToPlayClick(){
    this.moveTohowtoplay();
  }

  onHomeClick(){
    this.router.navigateByUrl("/home");
  }

  onReferalClick(){
    this.router.navigateByUrl("/aboutus");
  }

  onBody(){
    //this.moveToaboutus();
    this.router.navigateByUrl("/aboutus");
  }
  onAboutUsClick(){
   //this.router.navigateByUrl("/aboutus");
   this.moveToaboutus();
  }

  onLoginClick(){
    this.router.navigateByUrl("/aboutus");
  }

  onSubmitClick() {}

}
