import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-legality',
  templateUrl: './legality.component.html',
  styleUrls: ['./legality.component.scss']
})
export class LegalityComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
